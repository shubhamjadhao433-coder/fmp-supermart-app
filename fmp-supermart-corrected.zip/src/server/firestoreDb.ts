import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getFirestore,
  doc,
  collection,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  runTransaction,
  Firestore,
  DocumentData,
  QueryConstraint
} from 'firebase/firestore';
import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';
import {
  DEFAULT_WAREHOUSE_LAT,
  DEFAULT_WAREHOUSE_LNG,
  DEFAULT_WAREHOUSE_ADDRESS,
  DEFAULT_MAX_DELIVERY_DISTANCE_KM,
  DEFAULT_DELIVERY_SLABS,
  DeliverySlab,
  normalizeDeliverySlabs,
  calculateDeliveryFeeFromDistance
} from './deliveryDistance.ts';
import {
  QuantityPriceSlab,
  ProductPackagingType,
  normalizeProductType,
  normalizeProductPriceSlabs,
  resolveProductQuantityPricing
} from '../shared/quantityPricing.ts';

// Load config safely
let firebaseConfig: any = null;
try {
  const configPath = path.resolve(process.cwd(), 'firebase-applet-config.json');
  if (fs.existsSync(configPath)) {
    firebaseConfig = JSON.parse(fs.readFileSync(configPath, 'utf8'));
  }
} catch (e) {
  console.warn('[Firestore] Failed to read firebase-applet-config.json:', e);
}

if (!firebaseConfig) {
  throw new Error('firebase-applet-config.json is required for Firestore initialization');
}

const firebaseApp = !getApps().length ? initializeApp(firebaseConfig) : getApp();
export const firestoreDb: Firestore = getFirestore(
  firebaseApp,
  firebaseConfig.firestoreDatabaseId || '(default)'
);

// Helper for atomic sequence IDs per collection (e.g. counters/users -> nextId)
async function getNextId(sequenceName: string): Promise<number> {
  const counterRef = doc(firestoreDb, '_counters', sequenceName);
  return await runTransaction(firestoreDb, async (tx) => {
    const snap = await tx.get(counterRef);
    let current = 0;
    if (snap.exists()) {
      current = snap.data().current || 0;
    }
    const next = current + 1;
    tx.set(counterRef, { current: next, updated_at: new Date().toISOString() });
    return next;
  });
}

// Ensure counter has at least minimum value
async function ensureCounterMin(sequenceName: string, minVal: number): Promise<void> {
  const counterRef = doc(firestoreDb, '_counters', sequenceName);
  try {
    await runTransaction(firestoreDb, async (tx) => {
      const snap = await tx.get(counterRef);
      const current = snap.exists() ? (snap.data().current || 0) : 0;
      if (current < minVal) {
        tx.set(counterRef, { current: minVal, updated_at: new Date().toISOString() });
      }
    });
  } catch {}
}

// ----------------------------------------------------
// USERS REPOSITORY
// ----------------------------------------------------
export interface UserDoc {
  id: number;
  phone: string;
  name: string;
  email: string | null;
  role: 'customer' | 'admin' | 'rider' | 'store_owner';
  store_id?: number | null;
  password_hash: string;
  address: string | null;
  landmark: string | null;
  city: string;
  pincode: string;
  is_active: boolean;
  password_changed_at?: string | null;
  created_at: string;
}

export const usersRepo = {
  async findByPhone(phone: string): Promise<UserDoc[]> {
    const q = query(collection(firestoreDb, 'users'), where('phone', '==', phone));
    const snap = await getDocs(q);
    return snap.docs.map(d => d.data() as UserDoc);
  },

  async findByPhoneAndRole(phone: string, role: string): Promise<UserDoc | null> {
    const q = query(
      collection(firestoreDb, 'users'),
      where('phone', '==', phone),
      where('role', '==', role)
    );
    const snap = await getDocs(q);
    if (snap.empty) return null;
    return snap.docs[0].data() as UserDoc;
  },

  async findById(id: number): Promise<UserDoc | null> {
    const ref = doc(firestoreDb, 'users', String(id));
    const snap = await getDoc(ref);
    if (!snap.exists()) return null;
    return snap.data() as UserDoc;
  },

  async create(data: Omit<UserDoc, 'id'>): Promise<UserDoc> {
    const id = await getNextId('users');
    const userDoc: UserDoc = {
      ...data,
      id
    };
    await setDoc(doc(firestoreDb, 'users', String(id)), userDoc);
    return userDoc;
  },

  async update(id: number, data: Partial<UserDoc>): Promise<UserDoc | null> {
    const ref = doc(firestoreDb, 'users', String(id));
    const snap = await getDoc(ref);
    if (!snap.exists()) return null;
    const updated = { ...snap.data(), ...data, id };
    await setDoc(ref, updated, { merge: true });
    return updated as UserDoc;
  },

  async count(): Promise<number> {
    const snap = await getDocs(collection(firestoreDb, 'users'));
    return snap.size;
  },

  async listRiders(): Promise<UserDoc[]> {
    const q = query(collection(firestoreDb, 'users'), where('role', '==', 'rider'));
    const snap = await getDocs(q);
    return snap.docs.map(d => d.data() as UserDoc);
  },

  async listAdmins(): Promise<UserDoc[]> {
    const q = query(collection(firestoreDb, 'users'), where('role', '==', 'admin'));
    const snap = await getDocs(q);
    return snap.docs.map(d => d.data() as UserDoc);
  },

  async listCustomers(): Promise<UserDoc[]> {
    const q = query(collection(firestoreDb, 'users'), where('role', '==', 'customer'));
    const snap = await getDocs(q);
    return snap.docs
      .map(d => d.data() as UserDoc)
      .sort((a, b) => new Date(b.created_at || 0).getTime() - new Date(a.created_at || 0).getTime());
  }
};

// ----------------------------------------------------
// CATEGORIES REPOSITORY
// ----------------------------------------------------
export interface CategoryDoc {
  id: number;
  name: string;
  slug: string;
  description: string;
  image_url: string;
  display_order: number;
  is_active: boolean;
}

export const categoriesRepo = {
  async list(includeInactive: boolean = false): Promise<CategoryDoc[]> {
    const snap = await getDocs(collection(firestoreDb, 'categories'));
    const list = snap.docs
      .map(d => {
        const data = d.data() as CategoryDoc;
        const id = data.id !== undefined && data.id !== null ? Number(data.id) : (isNaN(Number(d.id)) ? d.id : Number(d.id));
        return { ...data, id } as CategoryDoc;
      })
      .filter(c => c.name && (includeInactive || c.is_active !== false));
    return list.sort((a, b) => (a.display_order || 0) - (b.display_order || 0) || (Number(a.id) || 0) - (Number(b.id) || 0));
  },

  async findById(id: number): Promise<CategoryDoc | null> {
    const ref = doc(firestoreDb, 'categories', String(id));
    const snap = await getDoc(ref);
    return snap.exists() ? (snap.data() as CategoryDoc) : null;
  },

  async findBySlug(slug: string): Promise<CategoryDoc | null> {
    const q = query(collection(firestoreDb, 'categories'), where('slug', '==', slug));
    const snap = await getDocs(q);
    return snap.empty ? null : (snap.docs[0].data() as CategoryDoc);
  },

  async create(data: Omit<CategoryDoc, 'id'>, customId?: number): Promise<CategoryDoc> {
    const id = customId || (await getNextId('categories'));
    const cat: CategoryDoc = { ...data, id };
    await setDoc(doc(firestoreDb, 'categories', String(id)), cat);
    return cat;
  },

  async update(id: number, data: Partial<CategoryDoc>): Promise<CategoryDoc | null> {
    const ref = doc(firestoreDb, 'categories', String(id));
    const snap = await getDoc(ref);
    if (!snap.exists()) return null;
    const updated = { ...snap.data(), ...data, id };
    await setDoc(ref, updated, { merge: true });
    return updated as CategoryDoc;
  },

  async remove(id: number): Promise<boolean> {
    const ref = doc(firestoreDb, 'categories', String(id));
    const snap = await getDoc(ref);
    if (!snap.exists()) return false;
    await deleteDoc(ref);
    return true;
  }
};

// ----------------------------------------------------
// STORES REPOSITORY (HYPERLOCAL KIRANA MARKETPLACE)
// ----------------------------------------------------
export interface StoreDoc {
  id: number;
  owner_id: number;
  owner_name: string;
  owner_phone: string;
  email?: string | null;
  name: string;
  description?: string | null;
  address: string;
  landmark?: string | null;
  city: string;
  district?: string | null;
  state?: string | null;
  pincode: string;
  lat: number;
  lng: number;
  logo_url?: string | null;
  banner_url?: string | null;
  photos: string[];
  opening_hours: string;
  opening_time?: string | null;
  closing_time?: string | null;
  weekly_closed_days?: string[];
  service_type: 'delivery' | 'pickup' | 'both';
  delivery_radius_km: number;
  delivery_fee: number;
  min_order_amount: number;
  delivery_info?: string | null;
  approval_status: 'pending' | 'approved' | 'rejected';
  rejection_reason?: string | null;
  is_active: boolean;
  is_open: boolean;
  // Future monetization flags (always disabled until Admin activates in future phase)
  featured?: boolean;
  subscription_tier?: 'free';
  created_at: string;
  updated_at: string;
}

export const storesRepo = {
  async listAll(): Promise<StoreDoc[]> {
    const snap = await getDocs(collection(firestoreDb, 'stores'));
    return snap.docs
      .map(d => d.data() as StoreDoc)
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
  },

  async listApprovedActive(): Promise<StoreDoc[]> {
    const snap = await getDocs(collection(firestoreDb, 'stores'));
    return snap.docs
      .map(d => d.data() as StoreDoc)
      .filter(s => s.approval_status === 'approved' && s.is_active !== false);
  },

  async findById(id: number): Promise<StoreDoc | null> {
    const ref = doc(firestoreDb, 'stores', String(id));
    const snap = await getDoc(ref);
    return snap.exists() ? (snap.data() as StoreDoc) : null;
  },

  async findByOwnerId(ownerId: number): Promise<StoreDoc | null> {
    const q = query(collection(firestoreDb, 'stores'), where('owner_id', '==', ownerId));
    const snap = await getDocs(q);
    if (snap.empty) return null;
    return snap.docs[0].data() as StoreDoc;
  },

  async create(data: Omit<StoreDoc, 'id'>): Promise<StoreDoc> {
    const id = await getNextId('stores');
    const storeDoc: StoreDoc = { ...data, id };
    await setDoc(doc(firestoreDb, 'stores', String(id)), storeDoc);
    return storeDoc;
  },

  async update(id: number, data: Partial<StoreDoc>): Promise<StoreDoc | null> {
    const ref = doc(firestoreDb, 'stores', String(id));
    const snap = await getDoc(ref);
    if (!snap.exists()) return null;
    const updated = { ...snap.data(), ...data, id, updated_at: new Date().toISOString() };
    await setDoc(ref, updated, { merge: true });
    return updated as StoreDoc;
  }
};

// ----------------------------------------------------
// COMPLAINTS / REPORTED PROBLEMS REPOSITORY
// ----------------------------------------------------
export interface ComplaintDoc {
  id: number;
  reporter_id: number;
  reporter_name: string;
  reporter_phone: string;
  reporter_role: string;
  store_id?: number | null;
  store_name?: string | null;
  order_id?: number | null;
  order_number?: string | null;
  product_id?: number | null;
  product_name?: string | null;
  subject: string;
  description: string;
  status: 'open' | 'in_review' | 'resolved' | 'rejected';
  admin_notes?: string | null;
  created_at: string;
  resolved_at?: string | null;
}

export const complaintsRepo = {
  async listAll(): Promise<ComplaintDoc[]> {
    const snap = await getDocs(collection(firestoreDb, 'complaints'));
    return snap.docs
      .map(d => d.data() as ComplaintDoc)
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
  },

  async listByReporter(reporterId: number): Promise<ComplaintDoc[]> {
    const q = query(collection(firestoreDb, 'complaints'), where('reporter_id', '==', reporterId));
    const snap = await getDocs(q);
    return snap.docs
      .map(d => d.data() as ComplaintDoc)
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
  },

  async create(data: Omit<ComplaintDoc, 'id' | 'created_at'>): Promise<ComplaintDoc> {
    const id = await getNextId('complaints');
    const docData: ComplaintDoc = {
      ...data,
      id,
      created_at: new Date().toISOString()
    };
    await setDoc(doc(firestoreDb, 'complaints', String(id)), docData);
    return docData;
  },

  async update(id: number, data: Partial<ComplaintDoc>): Promise<ComplaintDoc | null> {
    const ref = doc(firestoreDb, 'complaints', String(id));
    const snap = await getDoc(ref);
    if (!snap.exists()) return null;
    const updated = { ...snap.data(), ...data, id };
    await setDoc(ref, updated, { merge: true });
    return updated as ComplaintDoc;
  }
};

// ----------------------------------------------------
// PRODUCTS REPOSITORY
// ----------------------------------------------------
export interface ProductDoc {
  id: number;
  category_id: number;
  store_id?: number | null;
  store_name?: string | null;
  name: string;
  brand?: string | null;
  unit: string;
  price: number;
  mrp: number;
  discount_percent: number;
  stock: number;
  image_url: string | null;
  description: string | null;
  is_active: boolean;
  is_deleted?: boolean;
  product_type?: ProductPackagingType;
  min_order_qty?: number;
  max_order_qty?: number | null;
  pricing_slabs?: QuantityPriceSlab[];
  // Admin-only wholesale pricing & supplier details (NEVER returned to customers)
  purchase_cost?: number | null;
  gross_margin?: number | null;
  margin_percent?: number | null;
  supplier_id?: number | null;
  supplier_name?: string | null;
  supplier_phone?: string | null;
  supplier_address?: string | null;
  created_at: string;
  updated_at?: string;
}

export function computeWholesaleMetrics(price: number, purchaseCost?: number | null): {
  purchase_cost: number | null;
  gross_margin: number | null;
  margin_percent: number | null;
} {
  if (purchaseCost === undefined || purchaseCost === null || purchaseCost === ('' as any)) {
    return { purchase_cost: null, gross_margin: null, margin_percent: null };
  }
  const cost = Number(purchaseCost);
  if (!Number.isFinite(cost) || cost < 0) {
    return { purchase_cost: null, gross_margin: null, margin_percent: null };
  }
  const sellPrice = Number(price) || 0;
  const gross_margin = Number((sellPrice - cost).toFixed(2));
  const margin_percent = sellPrice > 0 ? Number((((sellPrice - cost) / sellPrice) * 100).toFixed(1)) : 0;
  return { purchase_cost: cost, gross_margin, margin_percent };
}

export function sanitizeProductForCustomer<T extends Record<string, any>>(product: T): Omit<
  T,
  | 'purchase_cost'
  | 'gross_margin'
  | 'margin_percent'
  | 'supplier_id'
  | 'supplier_name'
  | 'supplier_phone'
  | 'supplier_address'
> {
  if (!product) return product;
  const {
    purchase_cost: _pc,
    gross_margin: _gm,
    margin_percent: _mp,
    supplier_id: _sid,
    supplier_name: _sn,
    supplier_phone: _sp,
    supplier_address: _sa,
    ...publicFields
  } = product;
  return publicFields;
}

export const productsRepo = {
  async list(filters?: {
    category?: string;
    search?: string;
    in_stock?: boolean;
    includeWholesale?: boolean;
    includeCentral?: boolean;
    store_id?: number | null;
    includeInactive?: boolean;
    includeZeroStockUnavailable?: boolean;
  }): Promise<any[]> {
    const snap = await getDocs(collection(firestoreDb, 'products'));
    let products = snap.docs
      .map(d => {
        const data = d.data() as ProductDoc;
        const id = data.id !== undefined && data.id !== null ? Number(data.id) : (isNaN(Number(d.id)) ? d.id : Number(d.id));
        return { ...data, id } as ProductDoc;
      })
      .filter(
        p =>
          !p.is_deleted &&
          p.name &&
          p.price !== undefined &&
          (filters?.includeInactive ||
            p.is_active !== false ||
            (filters?.includeZeroStockUnavailable && Number(p.stock) <= 0))
      );

    const stores = await storesRepo.listAll();
    const storeMap = new Map(stores.map(s => [s.id, s]));

    if (filters?.store_id !== undefined) {
      if (filters.store_id === null) {
        products = products.filter(p => !p.store_id);
      } else {
        products = products.filter(p => p.store_id === filters.store_id);
      }
    } else {
      if (!filters?.includeCentral) {
        products = products.filter(p => Boolean(p.store_id && Number(p.store_id) > 0));
      }
      if (!filters?.includeWholesale && !filters?.includeInactive) {
        // Public catalog must never leak products from unapproved or deactivated stores
        products = products.filter(p => {
          if (!p.store_id) return Boolean(filters?.includeCentral);
          const st = storeMap.get(p.store_id);
          return Boolean(st && st.approval_status === 'approved' && st.is_active !== false);
        });
      }
    }

    const categories = await categoriesRepo.list(true);
    const catMap = new Map(categories.map(c => [c.id, c]));

    // Reviews summary map
    const reviewsSnap = await getDocs(collection(firestoreDb, 'reviews'));
    const approvedReviews = reviewsSnap.docs
      .map(d => d.data())
      .filter((r: any) => r.status === 'approved');

    const ratingMap: Record<number, { count: number; sum: number }> = {};
    for (const r of approvedReviews) {
      if (!ratingMap[r.product_id]) ratingMap[r.product_id] = { count: 0, sum: 0 };
      ratingMap[r.product_id].count++;
      ratingMap[r.product_id].sum += Number(r.rating) || 5;
    }

    if (filters?.category && filters.category !== 'all') {
      const matchCat = categories.find(
        c => c.slug === filters.category || c.name.toLowerCase() === filters.category?.toLowerCase()
      );
      if (matchCat) {
        products = products.filter(p => p.category_id === matchCat.id);
      }
    }

    if (filters?.search) {
      const s = filters.search.toLowerCase();
      products = products.filter(p => {
        const cat = catMap.get(p.category_id);
        const st = p.store_id ? storeMap.get(p.store_id) : null;
        return (
          p.name.toLowerCase().includes(s) ||
          (p.brand && p.brand.toLowerCase().includes(s)) ||
          (p.description && p.description.toLowerCase().includes(s)) ||
          String(p.id).includes(s) ||
          (cat && cat.name.toLowerCase().includes(s)) ||
          (st && st.name.toLowerCase().includes(s))
        );
      });
    }

    if (filters?.in_stock) {
      products = products.filter(p => p.stock > 0);
    }

    const includeWholesale = Boolean(filters?.includeWholesale);

    return products.map(p => {
      const cat = catMap.get(p.category_id);
      const st = p.store_id ? storeMap.get(p.store_id) : null;
      const r = ratingMap[p.id];
      const count = r ? r.count : 0;
      const avg = count > 0 ? Number((r.sum / count).toFixed(1)) : 0;
      const metrics = computeWholesaleMetrics(Number(p.price), p.purchase_cost);
      const productType = normalizeProductType(p.product_type, p.unit);
      const pricingSlabs = normalizeProductPriceSlabs(p.pricing_slabs, productType === 'loose' ? 'kg' : '');
      const enriched = {
        ...p,
        store_name: st?.name || p.store_name || null,
        product_type: productType,
        min_order_qty: p.min_order_qty && Number(p.min_order_qty) > 0 ? Number(p.min_order_qty) : 1,
        max_order_qty: p.max_order_qty && Number(p.max_order_qty) > 0 ? Number(p.max_order_qty) : null,
        pricing_slabs: pricingSlabs,
        ...(includeWholesale
          ? {
              purchase_cost: metrics.purchase_cost,
              gross_margin: metrics.gross_margin,
              margin_percent: metrics.margin_percent
            }
          : {}),
        category_name: cat?.name || 'Grocery',
        category_slug: cat?.slug || 'grocery',
        review_count: count,
        average_rating: avg
      };
      return includeWholesale ? enriched : sanitizeProductForCustomer(enriched);
    });
  },

  async findById(id: number): Promise<ProductDoc | null> {
    const ref = doc(firestoreDb, 'products', String(id));
    const snap = await getDoc(ref);
    if (!snap.exists()) return null;
    const p = snap.data() as ProductDoc;
    const productType = normalizeProductType(p.product_type, p.unit);
    return {
      ...p,
      product_type: productType,
      min_order_qty: p.min_order_qty && Number(p.min_order_qty) > 0 ? Number(p.min_order_qty) : 1,
      max_order_qty: p.max_order_qty && Number(p.max_order_qty) > 0 ? Number(p.max_order_qty) : null,
      pricing_slabs: normalizeProductPriceSlabs(p.pricing_slabs, productType === 'loose' ? 'kg' : '')
    };
  },

  async create(data: Omit<ProductDoc, 'id'>, customId?: number): Promise<ProductDoc> {
    const id = customId || (await getNextId('products'));
    const prod: ProductDoc = { ...data, id };
    await setDoc(doc(firestoreDb, 'products', String(id)), prod);
    return prod;
  },

  async update(id: number, data: Partial<ProductDoc>): Promise<ProductDoc | null> {
    const ref = doc(firestoreDb, 'products', String(id));
    const snap = await getDoc(ref);
    if (!snap.exists()) return null;
    const updated = { ...snap.data(), ...data, updated_at: new Date().toISOString() };
    await setDoc(ref, updated, { merge: true });
    return updated as ProductDoc;
  },

  async isProductReferencedInOrders(id: number): Promise<boolean> {
    const q = query(collection(firestoreDb, 'order_items'), where('product_id', '==', id), limit(1));
    const snap = await getDocs(q);
    return !snap.empty;
  },

  async softDelete(id: number): Promise<boolean> {
    const ref = doc(firestoreDb, 'products', String(id));
    const snap = await getDoc(ref);
    if (!snap.exists()) return false;
    await updateDoc(ref, { is_active: false, is_deleted: true, updated_at: new Date().toISOString() });
    return true;
  },

  async adjustStock(id: number, newStock: number, reason: string, adminId: number): Promise<ProductDoc> {
    const prodRef = doc(firestoreDb, 'products', String(id));
    return await runTransaction(firestoreDb, async (tx) => {
      const snap = await tx.get(prodRef);
      if (!snap.exists()) throw new Error('Product not found.');
      const prod = snap.data() as ProductDoc;
      const diff = newStock - prod.stock;

      const updated = {
        ...prod,
        stock: newStock,
        updated_at: new Date().toISOString()
      };
      tx.set(prodRef, updated, { merge: true });

      // Inventory log
      const logId = await getNextId('inventory');
      const logRef = doc(firestoreDb, 'inventory', String(logId));
      tx.set(logRef, {
        id: logId,
        product_id: id,
        change_type: 'manual_adjust',
        quantity_change: diff,
        stock_after: newStock,
        reference_id: `ADMIN-${adminId}`,
        notes: reason || 'Admin manual stock adjustment',
        created_at: new Date().toISOString()
      });

      return updated;
    });
  },

  async storeAdjustStock(
    id: number,
    newStock: number,
    storeId: number,
    isActiveOverride?: boolean
  ): Promise<ProductDoc> {
    const prodRef = doc(firestoreDb, 'products', String(id));
    return await runTransaction(firestoreDb, async (tx) => {
      const snap = await tx.get(prodRef);
      if (!snap.exists()) throw new Error('Product not found.');
      const prod = snap.data() as ProductDoc;
      if (prod.store_id !== storeId) {
        throw new Error('Forbidden: You can only adjust inventory for your own store products.');
      }

      const diff = Math.round((newStock - prod.stock) * 100) / 100;
      let nextActive: boolean;
      if (newStock <= 0) {
        nextActive = false;
      } else if (typeof isActiveOverride === 'boolean') {
        nextActive = isActiveOverride;
      } else if (prod.stock <= 0) {
        nextActive = true;
      } else {
        nextActive = prod.is_active !== false;
      }

      const updated: ProductDoc = {
        ...prod,
        stock: newStock,
        is_active: nextActive,
        updated_at: new Date().toISOString()
      };
      tx.set(prodRef, updated, { merge: true });

      const logId = await getNextId('inventory');
      const logRef = doc(firestoreDb, 'inventory', String(logId));
      tx.set(logRef, {
        id: logId,
        product_id: id,
        change_type: 'store_stock_adjust',
        quantity_change: diff,
        stock_after: newStock,
        reference_id: `STORE-${storeId}`,
        notes: newStock <= 0 ? 'Stock reached 0; product automatically marked unavailable' : 'Store owner stock update',
        created_at: new Date().toISOString()
      });

      return updated;
    });
  },

  async listInventoryLogsForStore(storeId: number, limitCount: number = 60): Promise<any[]> {
    const storeProducts = await this.list({ store_id: storeId, includeInactive: true, includeWholesale: false });
    const prodMap = new Map<number, any>(storeProducts.map(p => [Number(p.id), p]));
    if (prodMap.size === 0) return [];
    const invSnap = await getDocs(collection(firestoreDb, 'inventory'));
    return invSnap.docs
      .map(d => d.data())
      .filter((log: any) => prodMap.has(Number(log.product_id)))
      .map((log: any) => ({
        ...log,
        product_name: prodMap.get(Number(log.product_id))?.name || `Product #${log.product_id}`,
        unit: prodMap.get(Number(log.product_id))?.unit || ''
      }))
      .sort((a: any, b: any) => new Date(b.created_at || 0).getTime() - new Date(a.created_at || 0).getTime())
      .slice(0, limitCount);
  }
};

// ----------------------------------------------------
// ORDERS & ORDER_ITEMS REPOSITORY
// ----------------------------------------------------
export interface OrderDoc {
  id: number;
  order_number: string;
  customer_id: number;
  customer_name: string;
  customer_phone: string;
  store_id?: number | null;
  store_name?: string | null;
  fulfillment_type?: 'delivery' | 'pickup';
  delivery_address: string;
  landmark: string;
  pincode: string;
  subtotal: number;
  regular_subtotal?: number;
  total_savings?: number;
  delivery_fee: number;
  handling_fee: number;
  tip_amount: number;
  total_amount: number;
  distance_km?: number | null;
  distance_source?: string | null;
  customer_lat?: number | null;
  customer_lng?: number | null;
  warehouse_lat?: number | null;
  warehouse_lng?: number | null;
  delivery_fee_rule?: string | null;
  payment_mode: 'COD' | 'Pay at Store' | string;
  payment_method?: string;
  payment_status?: 'pending' | 'paid' | 'cancelled';
  status: 'placed' | 'confirmed' | 'packed' | 'dispatched' | 'delivered' | 'cancelled';
  delivery_type: string;
  scheduled_date: string;
  time_slot: string;
  rider_id?: number | null;
  rider_name?: string | null;
  rider_phone?: string | null;
  delivery_otp?: string | null;
  pickup_code?: string | null;
  pickup_attempts?: number;
  otp_expires_at?: string | null;
  otp_attempts?: number;
  status_history?: Array<{ status: string; at: string; actor_role?: string; note?: string }>;
  failure_reason?: string | null;
  rejection_reason?: string | null;
  cancelled_by_role?: 'customer' | 'store_owner' | 'admin' | string | null;
  cancelled_at?: string | null;
  idempotency_key?: string | null;
  cod_collected: boolean;
  cod_collected_at?: string | null;
  cod_reconciled: boolean;
  cod_reconciled_at?: string | null;
  created_at: string;
  updated_at: string;
}

export interface OrderItemDoc {
  id: number;
  order_id: number;
  product_id: number;
  product_name: string;
  unit: string;
  product_type?: ProductPackagingType;
  price: number;
  regular_unit_price?: number;
  quantity: number;
  total: number;
  savings?: number;
  applied_slab_label?: string | null;
  image_url: string | null;
}

export const ordersRepo = {
  async createTransactional(
    orderPayload: {
      customerId: number;
      customerName: string;
      customerPhone: string;
      storeId?: number | null;
      fulfillmentType?: 'delivery' | 'pickup';
      paymentMode?: 'COD' | 'Pay at Store';
      idempotencyKey?: string | null;
      pickupCode?: string | null;
      address: string;
      landmark: string;
      pincode: string;
      deliveryType: string;
      scheduledDate: string;
      timeSlot: string;
      tipAmount: number;
      customerLat: number;
      customerLng: number;
      distanceKm: number;
      durationMins: number | null;
      distanceSource: 'osrm' | 'haversine_fallback';
    },
    items: { product_id: number; quantity: number }[],
    adminUsers: UserDoc[]
  ): Promise<{ order: OrderDoc; items: OrderItemDoc[] }> {
    const orderNumber = `FMP-KL-${Date.now().toString().slice(-6)}-${Math.floor(100 + Math.random() * 900)}`;
    const cleanIdemKey = orderPayload.idempotencyKey
      ? String(orderPayload.idempotencyKey).trim().replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 80)
      : '';

    return await runTransaction(firestoreDb, async (tx) => {
      const storeId = orderPayload.storeId ? Number(orderPayload.storeId) : null;
      const fulfillmentType: 'delivery' | 'pickup' =
        orderPayload.fulfillmentType === 'pickup' ? 'pickup' : 'delivery';
      const idemRef = cleanIdemKey
        ? doc(firestoreDb, 'order_idempotency', `${orderPayload.customerId}_${cleanIdemKey}`)
        : null;

      // -1. Atomic idempotency check (must execute before any writes)
      if (idemRef) {
        const idemSnap = await tx.get(idemRef);
        if (idemSnap.exists()) {
          const existingIdem = idemSnap.data();
          throw new Error(`DUPLICATE_ORDER:${existingIdem.order_id || ''}:Duplicate order prevented. This order has already been submitted.`);
        }
      }

      // 0. Enforce hyperlocal store order (must belong to an approved, active, open kirana store)
      if (!storeId) {
        throw new Error('Orders must be placed with an approved local grocery store.');
      }
      const storeRef = doc(firestoreDb, 'stores', String(storeId));
      const storeSnap = await tx.get(storeRef);
      if (!storeSnap.exists()) {
        throw new Error('Selected grocery store was not found.');
      }
      const storeDoc: StoreDoc = storeSnap.data() as StoreDoc;
      if (storeDoc.approval_status !== 'approved' || storeDoc.is_active === false) {
        throw new Error('This store is currently not active on FMP Supermart.');
      }
      if (storeDoc.is_open === false) {
        throw new Error(`${storeDoc.name} is currently closed and not accepting orders.`);
      }
      const supportsDelivery = storeDoc.service_type === 'delivery' || storeDoc.service_type === 'both';
      const supportsPickup = storeDoc.service_type === 'pickup' || storeDoc.service_type === 'both';
      if (fulfillmentType === 'delivery' && !supportsDelivery) {
        throw new Error(`${storeDoc.name} only supports Store Pickup.`);
      }
      if (fulfillmentType === 'pickup' && !supportsPickup) {
        throw new Error(`${storeDoc.name} only supports Home Delivery.`);
      }

      // 1. Fetch & validate all items atomically (backend quantity-slab pricing + stock/min/max + store isolation check)
      let subtotal = 0;
      let regularSubtotal = 0;
      let totalSavings = 0;
      const validatedItems: {
        product: ProductDoc;
        requestedQty: number;
        appliedUnitPrice: number;
        regularUnitPrice: number;
        itemTotal: number;
        savings: number;
        appliedSlabLabel: string | null;
        productType: ProductPackagingType;
      }[] = [];

      for (const it of items) {
        const prodRef = doc(firestoreDb, 'products', String(it.product_id));
        const prodSnap = await tx.get(prodRef);
        if (!prodSnap.exists()) {
          throw new Error(`Product #${it.product_id} is no longer available.`);
        }
        const product = prodSnap.data() as ProductDoc;
        if (product.is_deleted || product.is_active === false) {
          throw new Error(`"${product.name}" is currently unavailable.`);
        }
        if (storeId && product.store_id !== storeId) {
          throw new Error(`"${product.name}" does not belong to ${storeDoc?.name || 'the selected store'}. All cart items must come from one store.`);
        }
        if (!storeId && product.store_id) {
          throw new Error(`"${product.name}" belongs to a local store. Please order it directly from that store.`);
        }

        const resolved = resolveProductQuantityPricing(product, Number(it.quantity));
        if (!resolved.valid) {
          throw new Error(resolved.error || `Invalid order quantity for "${product.name}".`);
        }

        subtotal = Math.round((subtotal + resolved.line_total) * 100) / 100;
        regularSubtotal = Math.round((regularSubtotal + resolved.regular_total) * 100) / 100;
        totalSavings = Math.round((totalSavings + resolved.savings) * 100) / 100;

        validatedItems.push({
          product,
          requestedQty: resolved.quantity,
          appliedUnitPrice: resolved.applied_unit_price,
          regularUnitPrice: resolved.regular_unit_price,
          itemTotal: resolved.line_total,
          savings: resolved.savings,
          appliedSlabLabel: resolved.applied_slab_label,
          productType: resolved.product_type
        });
      }

      // 2. Compute authoritative store-managed delivery fee (handling_fee & tip_amount strictly 0)
      let deliveryFee = 0;
      const handlingFee = 0;
      let distanceKm = orderPayload.distanceKm;
      const distanceSource = orderPayload.distanceSource;
      const warehouseLat = storeDoc.lat;
      const warehouseLng = storeDoc.lng;
      let matchedSlabLabel: string | null = null;

      if (storeDoc.min_order_amount > 0 && subtotal < storeDoc.min_order_amount) {
        throw new Error(`Minimum order amount for ${storeDoc.name} is ₹${storeDoc.min_order_amount}.`);
      }
      if (fulfillmentType === 'pickup') {
        deliveryFee = 0;
        distanceKm = 0;
        matchedSlabLabel = 'Store Pickup (Free)';
      } else {
        if (storeDoc.delivery_radius_km > 0 && distanceKm > storeDoc.delivery_radius_km) {
          throw new Error(
            `Your selected location (${distanceKm} km) is outside ${storeDoc.name}'s ${storeDoc.delivery_radius_km} km delivery radius.`
          );
        }
        deliveryFee = Math.max(0, Number(storeDoc.delivery_fee || 0));
        matchedSlabLabel = deliveryFee === 0 ? 'Free Store-Managed Delivery' : `Store-Managed Delivery (₹${deliveryFee})`;
      }

      const tipAmount = 0;
      const totalAmount = Math.round((subtotal + deliveryFee) * 100) / 100;

      // 3. Atomically deduct stock & write inventory logs
      for (const vi of validatedItems) {
        const newStock = Math.max(0, Math.round((vi.product.stock - vi.requestedQty) * 100) / 100);
        const prodRef = doc(firestoreDb, 'products', String(vi.product.id));
        const stockPatch: Record<string, any> = {
          stock: newStock,
          updated_at: new Date().toISOString()
        };
        if (vi.product.store_id && newStock <= 0) {
          stockPatch.is_active = false;
        }
        tx.update(prodRef, stockPatch);

        const logId = Date.now() + Math.floor(Math.random() * 10000);
        const logRef = doc(firestoreDb, 'inventory', String(logId));
        tx.set(logRef, {
          id: logId,
          product_id: vi.product.id,
          change_type: 'order_reserve',
          quantity_change: -vi.requestedQty,
          stock_after: newStock,
          reference_id: orderNumber,
          notes: `Reserved for order ${orderNumber}`,
          created_at: new Date().toISOString()
        });
      }

      // 4. Create Order Doc (saving immutable distance, coordinates, pricing savings, and fee snapshot)
      const orderId = Date.now() + Math.floor(Math.random() * 1000);
      const nowIso = new Date().toISOString();
      const resolvedPaymentMode: 'COD' | 'Pay at Store' =
        fulfillmentType === 'pickup' && orderPayload.paymentMode === 'Pay at Store' ? 'Pay at Store' : 'COD';
      const resolvedPaymentMethod = fulfillmentType === 'pickup' ? 'Pay at Store' : 'Cash on Delivery';

      const newOrder: OrderDoc = {
        id: orderId,
        order_number: orderNumber,
        customer_id: orderPayload.customerId,
        customer_name: orderPayload.customerName,
        customer_phone: orderPayload.customerPhone,
        store_id: storeDoc ? storeDoc.id : null,
        store_name: storeDoc ? storeDoc.name : null,
        fulfillment_type: fulfillmentType,
        delivery_address: fulfillmentType === 'pickup' && storeDoc ? `Store Pickup: ${storeDoc.name}, ${storeDoc.address}` : orderPayload.address,
        landmark: orderPayload.landmark,
        pincode: orderPayload.pincode,
        subtotal,
        regular_subtotal: regularSubtotal,
        total_savings: totalSavings,
        delivery_fee: deliveryFee,
        handling_fee: handlingFee,
        tip_amount: tipAmount,
        total_amount: totalAmount,
        distance_km: distanceKm,
        distance_source: distanceSource,
        customer_lat: orderPayload.customerLat,
        customer_lng: orderPayload.customerLng,
        warehouse_lat: warehouseLat,
        warehouse_lng: warehouseLng,
        delivery_fee_rule: matchedSlabLabel,
        payment_mode: resolvedPaymentMode,
        payment_method: resolvedPaymentMethod,
        payment_status: 'pending',
        status: 'placed',
        delivery_type: orderPayload.deliveryType,
        scheduled_date: orderPayload.scheduledDate,
        time_slot: fulfillmentType === 'pickup' ? 'Store Pickup' : orderPayload.timeSlot,
        pickup_code: fulfillmentType === 'pickup' ? (orderPayload.pickupCode || null) : null,
        pickup_attempts: 0,
        status_history: [
          {
            status: 'placed',
            at: nowIso,
            actor_role: 'customer',
            note: fulfillmentType === 'pickup' ? 'Store pickup order placed' : 'Home delivery order placed'
          }
        ],
        idempotency_key: cleanIdemKey || null,
        cod_collected: false,
        cod_reconciled: false,
        created_at: nowIso,
        updated_at: nowIso
      };

      const orderRef = doc(firestoreDb, 'orders', String(orderId));
      tx.set(orderRef, newOrder);

      // Record initial payment_history event atomically
      const payId = Date.now() + 300 + Math.floor(Math.random() * 500);
      tx.set(doc(firestoreDb, 'payment_history', String(payId)), {
        id: payId,
        order_id: orderId,
        order_number: orderNumber,
        store_id: storeDoc.id,
        customer_id: orderPayload.customerId,
        amount: totalAmount,
        payment_mode: resolvedPaymentMode,
        payment_status: 'pending',
        event: 'order_placed',
        created_at: nowIso
      });

      if (idemRef) {
        tx.set(idemRef, {
          order_id: orderId,
          order_number: orderNumber,
          customer_id: orderPayload.customerId,
          created_at: nowIso
        });
      }

      // 5. Create Order Items (saving immutable applied_unit_price, quantity, savings, and slab snapshot)
      const createdItems: OrderItemDoc[] = [];
      let itemCounter = 0;
      for (const vi of validatedItems) {
        itemCounter++;
        const itemId = Date.now() + itemCounter + Math.floor(Math.random() * 500);
        const itemDoc: OrderItemDoc = {
          id: itemId,
          order_id: orderId,
          product_id: vi.product.id,
          product_name: vi.product.name,
          unit: vi.product.unit,
          product_type: vi.productType,
          price: vi.appliedUnitPrice,
          regular_unit_price: vi.regularUnitPrice,
          quantity: vi.requestedQty,
          total: vi.itemTotal,
          savings: vi.savings,
          applied_slab_label: vi.appliedSlabLabel,
          image_url: vi.product.image_url
        };
        const itemRef = doc(firestoreDb, 'order_items', String(itemId));
        tx.set(itemRef, itemDoc);
        createdItems.push(itemDoc);
      }

      // 6. Notifications (Customer + Store Owner / Admins)
      const custNotifId = Date.now() + 800;
      tx.set(doc(firestoreDb, 'notifications', String(custNotifId)), {
        id: custNotifId,
        user_id: orderPayload.customerId,
        title: 'Order Placed Successfully! 🎉',
        message: storeDoc
          ? `Your ${fulfillmentType === 'pickup' ? 'Store Pickup' : 'Delivery'} order #${orderNumber} at ${storeDoc.name} for ₹${totalAmount} has been placed.`
          : `Your FMP Supermart order #${orderNumber} for ₹${totalAmount} has been placed. Payment via Cash on Delivery.`,
        type: 'order',
        is_read: false,
        order_id: orderId,
        created_at: nowIso
      });

      if (storeDoc) {
        const ownerNotifId = Date.now() + 830 + storeDoc.owner_id;
        tx.set(doc(firestoreDb, 'notifications', String(ownerNotifId)), {
          id: ownerNotifId,
          user_id: storeDoc.owner_id,
          title: `New ${fulfillmentType === 'pickup' ? 'Pickup' : 'Delivery'} Order! 🛒`,
          message: `Order #${orderNumber} for ₹${totalAmount} placed by ${orderPayload.customerName} (${orderPayload.customerPhone}).`,
          type: 'order',
          is_read: false,
          order_id: orderId,
          created_at: nowIso
        });
      }

      for (const adm of adminUsers) {
        const admNotifId = Date.now() + 850 + adm.id;
        tx.set(doc(firestoreDb, 'notifications', String(admNotifId)), {
          id: admNotifId,
          user_id: adm.id,
          title: storeDoc ? `Store Order Received (${storeDoc.name}) 🛒` : 'New Order Received! 🛒',
          message: `Order #${orderNumber} for ₹${totalAmount} placed by ${orderPayload.customerName} (${orderPayload.customerPhone}).`,
          type: 'order',
          is_read: false,
          order_id: orderId,
          created_at: nowIso
        });
      }

      return { order: newOrder, items: createdItems };
    });
  },

  async list(filters?: { customer_id?: number; rider_id?: number; store_id?: number }): Promise<OrderDoc[]> {
    const snap = await getDocs(collection(firestoreDb, 'orders'));
    let orders = snap.docs.map(d => d.data() as OrderDoc);
    if (filters?.customer_id) {
      orders = orders.filter(o => o.customer_id === filters.customer_id);
    }
    if (filters?.rider_id) {
      orders = orders.filter(o => o.rider_id === filters.rider_id);
    }
    if (filters?.store_id) {
      orders = orders.filter(o => o.store_id === filters.store_id);
    }
    return orders.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
  },

  async listItemsMap(): Promise<Map<number, OrderItemDoc[]>> {
    const itemsSnap = await getDocs(collection(firestoreDb, 'order_items'));
    const map = new Map<number, OrderItemDoc[]>();
    for (const d of itemsSnap.docs) {
      const it = d.data() as OrderItemDoc;
      if (!map.has(it.order_id)) map.set(it.order_id, []);
      map.get(it.order_id)!.push(it);
    }
    return map;
  },

  async findById(id: number): Promise<{ order: OrderDoc | null; items: OrderItemDoc[] }> {
    const orderRef = doc(firestoreDb, 'orders', String(id));
    const orderSnap = await getDoc(orderRef);
    if (!orderSnap.exists()) return { order: null, items: [] };

    const itemsSnap = await getDocs(collection(firestoreDb, 'order_items'));
    const items = itemsSnap.docs
      .map(d => d.data() as OrderItemDoc)
      .filter(i => i.order_id === id);

    return { order: orderSnap.data() as OrderDoc, items };
  },

  async cancelOrderTransactional(
    orderId: number,
    reason: string,
    cancelledBy: { id: number; name: string; role: string },
    adminUsers: UserDoc[]
  ): Promise<OrderDoc> {
    const orderRef = doc(firestoreDb, 'orders', String(orderId));

    return await runTransaction(firestoreDb, async (tx) => {
      const snap = await tx.get(orderRef);
      if (!snap.exists()) throw new Error('Order not found.');
      const order = snap.data() as OrderDoc;

      if (['delivered', 'cancelled'].includes(order.status)) {
        throw new Error(`Order cannot be cancelled because it is already ${order.status}.`);
      }
      if (order.status === 'dispatched' && cancelledBy.role === 'customer') {
        throw new Error(
          order.fulfillment_type === 'pickup'
            ? 'Order is already ready for pickup. Please contact the store to cancel.'
            : 'Order is already out for delivery. Please contact the store or FMP Supermart support to cancel.'
        );
      }

      // Read store owner (if store order) BEFORE writes
      let storeOwnerId: number | null = null;
      if (order.store_id) {
        const stSnap = await tx.get(doc(firestoreDb, 'stores', String(order.store_id)));
        if (stSnap.exists()) {
          storeOwnerId = (stSnap.data() as StoreDoc).owner_id || null;
        }
      }

      // Restore items stock (read ALL product docs before any writes)
      const itemsSnap = await getDocs(collection(firestoreDb, 'order_items'));
      const items = itemsSnap.docs
        .map(d => d.data() as OrderItemDoc)
        .filter(i => i.order_id === orderId);

      const prodSnapshots = await Promise.all(
        items.map(async (item) => {
          const prodRef = doc(firestoreDb, 'products', String(item.product_id));
          const prodSnap = await tx.get(prodRef);
          return { item, prodRef, prodSnap };
        })
      );

      for (let idx = 0; idx < prodSnapshots.length; idx++) {
        const { item, prodRef, prodSnap } = prodSnapshots[idx];
        if (prodSnap.exists()) {
          const prod = prodSnap.data() as ProductDoc;
          const restoredStock = Math.round((prod.stock + item.quantity) * 100) / 100;
          const restorePatch: Record<string, any> = {
            stock: restoredStock,
            updated_at: new Date().toISOString()
          };
          if (prod.store_id && prod.stock <= 0 && restoredStock > 0) {
            restorePatch.is_active = true;
          }
          tx.update(prodRef, restorePatch);

          const logId = Date.now() + idx + Math.floor(Math.random() * 1000);
          tx.set(doc(firestoreDb, 'inventory', String(logId)), {
            id: logId,
            product_id: item.product_id,
            change_type: 'order_cancel_restore',
            quantity_change: item.quantity,
            stock_after: restoredStock,
            reference_id: order.order_number,
            notes: `Restored from cancelled order ${order.order_number}`,
            created_at: new Date().toISOString()
          });
        }
      }

      const nowIso = new Date().toISOString();
      const isStoreOrAdminReject = cancelledBy.role === 'store_owner' || cancelledBy.role === 'admin';
      const cleanReason = reason?.trim() || (isStoreOrAdminReject ? `Rejected by ${cancelledBy.name}` : 'Cancelled by customer');

      const existingHistory = Array.isArray(order.status_history) ? order.status_history : [];
      const updatedOrder: OrderDoc = {
        ...order,
        status: 'cancelled',
        payment_status: 'cancelled',
        failure_reason: cleanReason,
        rejection_reason: isStoreOrAdminReject ? cleanReason : (order.rejection_reason ?? null),
        cancelled_by_role: cancelledBy.role,
        cancelled_at: nowIso,
        status_history: [
          ...existingHistory,
          { status: 'cancelled', at: nowIso, actor_role: cancelledBy.role, note: cleanReason }
        ],
        updated_at: nowIso
      };
      tx.set(orderRef, updatedOrder);

      const payId = Date.now() + 25 + Math.floor(Math.random() * 500);
      tx.set(doc(firestoreDb, 'payment_history', String(payId)), {
        id: payId,
        order_id: orderId,
        order_number: order.order_number,
        store_id: order.store_id || null,
        customer_id: order.customer_id,
        amount: order.total_amount,
        payment_mode: order.payment_mode,
        payment_status: 'cancelled',
        event: isStoreOrAdminReject ? 'order_rejected' : 'order_cancelled',
        created_at: nowIso
      });

      // Customer Notification
      const cNotifId = Date.now() + 10;
      tx.set(doc(firestoreDb, 'notifications', String(cNotifId)), {
        id: cNotifId,
        user_id: order.customer_id,
        title: isStoreOrAdminReject ? 'Order Rejected by Store' : 'Order Cancelled',
        message: isStoreOrAdminReject
          ? `Order #${order.order_number} was rejected (${cleanReason}).`
          : `Order #${order.order_number} has been cancelled. Reserved items have been released.`,
        type: 'order',
        is_read: false,
        order_id: orderId,
        created_at: nowIso
      });

      // Notify Store Owner if customer cancelled a store order
      if (storeOwnerId && cancelledBy.role === 'customer') {
        const sNotifId = Date.now() + 15 + storeOwnerId;
        tx.set(doc(firestoreDb, 'notifications', String(sNotifId)), {
          id: sNotifId,
          user_id: storeOwnerId,
          title: 'Order Cancelled by Customer',
          message: `Customer ${order.customer_name} cancelled order #${order.order_number}. Stock has been restored.`,
          type: 'order',
          is_read: false,
          order_id: orderId,
          created_at: nowIso
        });
      }

      // Admin Notifications
      for (const adm of adminUsers) {
        const aNotifId = Date.now() + 20 + adm.id;
        tx.set(doc(firestoreDb, 'notifications', String(aNotifId)), {
          id: aNotifId,
          user_id: adm.id,
          title: isStoreOrAdminReject ? 'Order Rejected ⚠️' : 'Order Cancelled ⚠️',
          message: `Order #${order.order_number} was ${isStoreOrAdminReject ? 'rejected' : 'cancelled'} by ${cancelledBy.name} (${cancelledBy.role}). Stock was restored.`,
          type: 'order',
          is_read: false,
          order_id: orderId,
          created_at: nowIso
        });
      }

      return updatedOrder;
    });
  },

  async updateStatus(
    id: number,
    status: OrderDoc['status'],
    extra?: { cod_collected?: boolean; cod_collected_at?: string; payment_status?: 'pending' | 'paid' | 'cancelled'; rejection_reason?: string }
  ): Promise<OrderDoc | null> {
    const ref = doc(firestoreDb, 'orders', String(id));
    const snap = await getDoc(ref);
    if (!snap.exists()) return null;
    const order = snap.data() as OrderDoc;
    const nowIso = new Date().toISOString();
    const existingHistory = Array.isArray(order.status_history) ? order.status_history : [];
    const updated: OrderDoc = {
      ...order,
      status,
      ...(status === 'delivered' ? { payment_status: 'paid' as const, cod_collected: true, cod_collected_at: extra?.cod_collected_at || nowIso } : {}),
      ...(extra || {}),
      status_history: [
        ...existingHistory,
        { status, at: nowIso, actor_role: 'store_owner', note: `Order marked ${status}` }
      ],
      updated_at: nowIso
    };
    await setDoc(ref, updated, { merge: true });

    if (status === 'delivered') {
      const payId = Date.now() + Math.floor(Math.random() * 500);
      await setDoc(doc(firestoreDb, 'payment_history', String(payId)), {
        id: payId,
        order_id: id,
        order_number: updated.order_number,
        store_id: updated.store_id || null,
        customer_id: updated.customer_id,
        amount: updated.total_amount,
        payment_mode: updated.payment_mode,
        payment_status: 'paid',
        event: 'payment_collected',
        created_at: nowIso
      });
    }

    const labelMap: Record<string, string> = {
      confirmed: 'accepted & confirmed',
      packed: 'being prepared',
      dispatched: order.fulfillment_type === 'pickup' ? 'ready for store pickup' : 'out for store delivery',
      delivered: 'completed',
      cancelled: 'cancelled'
    };

    await notificationsRepo.create({
      user_id: updated.customer_id,
      title: `Order Update: ${(labelMap[status] || status).toUpperCase()}`,
      message: updated.store_name
        ? `Your order #${updated.order_number} from ${updated.store_name} is now ${labelMap[status] || status}.`
        : `Your order #${updated.order_number} is now ${labelMap[status] || status}.`,
      type: 'order',
      order_id: id
    });

    return updated;
  },

  async verifyPickupAndComplete(
    id: number,
    storeId: number,
    inputCode: string,
    storeName: string
  ): Promise<OrderDoc> {
    const orderRef = doc(firestoreDb, 'orders', String(id));
    const snap = await getDoc(orderRef);
    if (!snap.exists()) throw new Error('Order not found.');
    const order = snap.data() as OrderDoc;

    if (order.store_id !== storeId) {
      throw new Error('Forbidden: This order belongs to another store.');
    }
    if (order.fulfillment_type !== 'pickup') {
      throw new Error('Pickup code verification applies only to store pickup orders.');
    }
    if (order.status !== 'dispatched') {
      throw new Error(`Order must be marked Ready for Pickup before completing pickup. Current status: ${order.status}`);
    }
    const attempts = Number(order.pickup_attempts || 0);
    if (attempts >= 5) {
      throw new Error('Maximum pickup code verification attempts exceeded. Please contact Admin for assistance.');
    }
    if (!inputCode || String(order.pickup_code || '') !== inputCode.trim()) {
      await updateDoc(orderRef, { pickup_attempts: attempts + 1, updated_at: new Date().toISOString() });
      throw new Error('Incorrect 6-digit pickup code. Please verify the code from the customer.');
    }

    const nowIso = new Date().toISOString();
    const existingHistory = Array.isArray(order.status_history) ? order.status_history : [];
    const completed: OrderDoc = {
      ...order,
      status: 'delivered',
      payment_status: 'paid',
      cod_collected: true,
      cod_collected_at: nowIso,
      status_history: [
        ...existingHistory,
        { status: 'delivered', at: nowIso, actor_role: 'store_owner', note: 'Pickup verified with customer 6-digit code' }
      ],
      updated_at: nowIso
    };
    await setDoc(orderRef, completed, { merge: true });

    const payId = Date.now() + Math.floor(Math.random() * 500);
    await setDoc(doc(firestoreDb, 'payment_history', String(payId)), {
      id: payId,
      order_id: id,
      order_number: completed.order_number,
      store_id: storeId,
      customer_id: completed.customer_id,
      amount: completed.total_amount,
      payment_mode: completed.payment_mode,
      payment_status: 'paid',
      event: 'pickup_verified_paid',
      created_at: nowIso
    });

    await notificationsRepo.create({
      user_id: completed.customer_id,
      title: 'Store Pickup Completed! 🛍️',
      message: `Your pickup order #${completed.order_number} at ${storeName} is complete. Thank you for shopping with FMP Supermart!`,
      type: 'order',
      order_id: id
    });

    return completed;
  },

  async assignRider(id: number, rider: UserDoc): Promise<OrderDoc | null> {
    const ref = doc(firestoreDb, 'orders', String(id));
    const snap = await getDoc(ref);
    if (!snap.exists()) return null;
    const order = snap.data() as OrderDoc;

    const nowIso = new Date().toISOString();
    const updated: OrderDoc = {
      ...order,
      rider_id: rider.id,
      rider_name: rider.name,
      rider_phone: rider.phone,
      updated_at: nowIso
    };
    await setDoc(ref, updated, { merge: true });

    // Notify rider
    await notificationsRepo.create({
      user_id: rider.id,
      title: 'New Order Assigned 🛵',
      message: `Order #${order.order_number} to ${order.customer_name} (${order.delivery_address}) assigned to you.`,
      type: 'order',
      order_id: id
    });

    // Notify customer
    await notificationsRepo.create({
      user_id: order.customer_id,
      title: 'Delivery Partner Assigned 🛵',
      message: `Delivery partner ${rider.name} (${rider.phone}) has been assigned to deliver order #${order.order_number}.`,
      type: 'order',
      order_id: id
    });

    return updated;
  },

  async updateDeliveryFee(id: number, newFee: number): Promise<OrderDoc | null> {
    const ref = doc(firestoreDb, 'orders', String(id));
    const snap = await getDoc(ref);
    if (!snap.exists()) return null;
    const order = snap.data() as OrderDoc;

    if (['delivered', 'cancelled'].includes(order.status)) {
      throw new Error(`Cannot alter delivery fee for an order that is already ${order.status}.`);
    }

    const tip = Number(order.tip_amount) || 0;
    const newTotal = Number(order.subtotal) + newFee + Number(order.handling_fee) + tip;
    const nowIso = new Date().toISOString();

    const updated: OrderDoc = {
      ...order,
      delivery_fee: newFee,
      total_amount: newTotal,
      updated_at: nowIso
    };
    await setDoc(ref, updated, { merge: true });

    await notificationsRepo.create({
      user_id: order.customer_id,
      title: 'Order Delivery Fee Updated',
      message: `Delivery fee for order #${order.order_number} was adjusted from ₹${order.delivery_fee} to ₹${newFee}. New payable COD amount: ₹${newTotal}.`,
      type: 'order',
      order_id: id
    });

    return updated;
  },

  async dispatch(id: number, otp: string, expiresAt: Date): Promise<OrderDoc | null> {
    const ref = doc(firestoreDb, 'orders', String(id));
    const snap = await getDoc(ref);
    if (!snap.exists()) return null;
    const order = snap.data() as OrderDoc;

    const nowIso = new Date().toISOString();
    const updated: OrderDoc = {
      ...order,
      status: 'dispatched',
      delivery_otp: otp,
      otp_expires_at: expiresAt.toISOString(),
      otp_attempts: 0,
      updated_at: nowIso
    };
    await setDoc(ref, updated, { merge: true });

    // Customer Notification
    await notificationsRepo.create({
      user_id: order.customer_id,
      title: 'Order Out for Delivery! 🚀',
      message: `Your order #${order.order_number} is out for delivery with ${order.rider_name || 'our delivery partner'}. Keep ₹${order.total_amount} ready in cash. Share your secure OTP only when you receive your package.`,
      type: 'order',
      order_id: id
    });

    // Rider Notification
    if (order.rider_id) {
      await notificationsRepo.create({
        user_id: order.rider_id,
        title: 'Order Ready for Pickup & Delivery',
        message: `Order #${order.order_number} has been dispatched. Pick up package from central warehouse and deliver to ${order.customer_name}. Collect COD: ₹${order.total_amount}.`,
        type: 'order',
        order_id: id
      });
    }

    return updated;
  },

  async verifyOtpAndDeliverTransactional(
    id: number,
    inputOtp: string,
    rider: UserDoc,
    adminUsers: UserDoc[]
  ): Promise<OrderDoc> {
    const orderRef = doc(firestoreDb, 'orders', String(id));

    return await runTransaction(firestoreDb, async (tx) => {
      const snap = await tx.get(orderRef);
      if (!snap.exists()) throw new Error('Order not found.');
      const order = snap.data() as OrderDoc;

      if (rider.role === 'rider' && order.rider_id !== rider.id) {
        throw new Error('This order is not assigned to you.');
      }
      if (order.status === 'delivered') {
        throw new Error('Order has already been delivered and verified.');
      }
      if (order.status !== 'dispatched') {
        throw new Error(`Order must be dispatched before OTP verification. Current status: ${order.status}`);
      }
      if ((order.otp_attempts || 0) >= 5) {
        throw new Error('Maximum OTP verification attempts exceeded. Please contact admin.');
      }

      if (order.delivery_otp !== inputOtp) {
        const newAttempts = (order.otp_attempts || 0) + 1;
        tx.update(orderRef, { otp_attempts: newAttempts });
        throw new Error('Incorrect Delivery OTP. Please verify with the customer.');
      }

      const nowIso = new Date().toISOString();
      const delivered: OrderDoc = {
        ...order,
        status: 'delivered',
        payment_status: 'paid',
        cod_collected: true,
        cod_collected_at: nowIso,
        updated_at: nowIso
      };
      tx.set(orderRef, delivered);

      // Customer Notification
      const cNotifId = Date.now() + 50;
      tx.set(doc(firestoreDb, 'notifications', String(cNotifId)), {
        id: cNotifId,
        user_id: order.customer_id,
        title: 'Order Delivered! 🛍️',
        message: `Your order #${order.order_number} has been delivered by ${rider.name}. ₹${order.total_amount} COD received. Thank you for choosing FMP Supermart!`,
        type: 'order',
        is_read: false,
        order_id: id,
        created_at: nowIso
      });

      // Admin Notifications
      for (const adm of adminUsers) {
        const aNotifId = Date.now() + 60 + adm.id;
        tx.set(doc(firestoreDb, 'notifications', String(aNotifId)), {
          id: aNotifId,
          user_id: adm.id,
          title: 'Order Delivered & COD Collected ✅',
          message: `Order #${order.order_number} delivered by ${rider.name}. Collected ₹${order.total_amount} in Cash.`,
          type: 'order',
          is_read: false,
          order_id: id,
          created_at: nowIso
        });
      }

      return delivered;
    });
  },

  async reportDeliveryFailure(id: number, reason: string): Promise<OrderDoc | null> {
    const ref = doc(firestoreDb, 'orders', String(id));
    const snap = await getDoc(ref);
    if (!snap.exists()) return null;
    const nowIso = new Date().toISOString();
    const updated = { ...snap.data(), failure_reason: reason, updated_at: nowIso };
    await setDoc(ref, updated, { merge: true });
    return updated as OrderDoc;
  }
};

// ----------------------------------------------------
// SETTINGS REPOSITORY
// ----------------------------------------------------
export interface DeliverySettingsDoc {
  default_delivery_fee: number;
  handling_fee: number;
  min_order_amount: number;
  delivery_areas: string;
  warehouse_lat: number;
  warehouse_lng: number;
  warehouse_address: string;
  delivery_pricing_mode: 'slabs' | 'per_km';
  per_km_rate: number;
  free_delivery_up_to_km: number;
  max_delivery_distance_km: number;
  delivery_slabs: DeliverySlab[];
  updated_at: string;
}

export const settingsRepo = {
  async getDeliverySettings(): Promise<DeliverySettingsDoc> {
    const ref = doc(firestoreDb, 'settings', 'delivery');
    const snap = await getDoc(ref);
    const defaults: DeliverySettingsDoc = {
      default_delivery_fee: 0,
      handling_fee: 5,
      min_order_amount: 0,
      delivery_areas: JSON.stringify([
        { pincode: '444105', area: 'Karanja Lad City Center', fee: 0 },
        { pincode: '444105', area: 'Station Road & APMC', fee: 10 },
        { pincode: '444105', area: 'Outskirts / Rural Karanja', fee: 30 }
      ]),
      warehouse_lat: DEFAULT_WAREHOUSE_LAT,
      warehouse_lng: DEFAULT_WAREHOUSE_LNG,
      warehouse_address: DEFAULT_WAREHOUSE_ADDRESS,
      delivery_pricing_mode: 'slabs',
      per_km_rate: 8,
      free_delivery_up_to_km: 0,
      max_delivery_distance_km: DEFAULT_MAX_DELIVERY_DISTANCE_KM,
      delivery_slabs: DEFAULT_DELIVERY_SLABS,
      updated_at: new Date().toISOString()
    };

    if (!snap.exists()) {
      await setDoc(ref, defaults);
      return defaults;
    }

    const existing = snap.data() as Partial<DeliverySettingsDoc>;
    const merged: DeliverySettingsDoc = {
      ...defaults,
      ...existing,
      warehouse_lat: Number(existing.warehouse_lat ?? defaults.warehouse_lat),
      warehouse_lng: Number(existing.warehouse_lng ?? defaults.warehouse_lng),
      warehouse_address: existing.warehouse_address || defaults.warehouse_address,
      delivery_pricing_mode: existing.delivery_pricing_mode === 'per_km' ? 'per_km' : 'slabs',
      per_km_rate: Number(existing.per_km_rate ?? defaults.per_km_rate),
      free_delivery_up_to_km: Number(existing.free_delivery_up_to_km ?? defaults.free_delivery_up_to_km),
      max_delivery_distance_km: Number(existing.max_delivery_distance_km ?? defaults.max_delivery_distance_km),
      delivery_slabs: normalizeDeliverySlabs(existing.delivery_slabs),
      handling_fee: Number(existing.handling_fee ?? defaults.handling_fee),
      default_delivery_fee: Number(existing.default_delivery_fee ?? defaults.default_delivery_fee),
      min_order_amount: Number(existing.min_order_amount ?? 0),
      delivery_areas: existing.delivery_areas || defaults.delivery_areas,
      updated_at: existing.updated_at || defaults.updated_at
    };

    // Persist new schema fields onto Firestore if the existing document predates distance-based config
    if (existing.warehouse_lat === undefined || !Array.isArray(existing.delivery_slabs)) {
      await setDoc(ref, merged, { merge: true });
    }

    return merged;
  },

  async updateDeliverySettings(data: Partial<DeliverySettingsDoc>): Promise<DeliverySettingsDoc> {
    const ref = doc(firestoreDb, 'settings', 'delivery');
    const current = await this.getDeliverySettings();
    const updated: DeliverySettingsDoc = {
      ...current,
      ...data,
      delivery_slabs: data.delivery_slabs ? normalizeDeliverySlabs(data.delivery_slabs) : current.delivery_slabs,
      updated_at: new Date().toISOString()
    };
    await setDoc(ref, updated);
    return updated;
  },

  async getPlatformSettings(): Promise<PlatformSettingsDoc> {
    const ref = doc(firestoreDb, 'settings', 'platform_config');
    const snap = await getDoc(ref);
    const defaults: PlatformSettingsDoc = {
      platform_name: 'FMP Supermart',
      support_phone: '9699925206',
      support_email: 'support@fmpsupermart.in',
      city: 'All India',
      require_store_approval: true,
      store_visibility_rule: 'approved_active_valid_location',
      service_available: true,
      maintenance_message: '',
      monetization_enabled: false,
      subscriptions_enabled: false,
      featured_stores_enabled: false,
      store_ads_enabled: false,
      admob_enabled: false,
      adsense_enabled: false,
      updated_at: new Date().toISOString()
    };

    if (!snap.exists()) {
      await setDoc(ref, defaults);
      return defaults;
    }

    const existing = snap.data() as Partial<PlatformSettingsDoc>;
    return {
      ...defaults,
      ...existing,
      require_store_approval: existing.require_store_approval !== false,
      store_visibility_rule:
        existing.store_visibility_rule === 'approved_active_open_only'
          ? 'approved_active_open_only'
          : 'approved_active_valid_location',
      service_available: existing.service_available !== false,
      monetization_enabled: false,
      subscriptions_enabled: false,
      featured_stores_enabled: false,
      store_ads_enabled: false,
      admob_enabled: false,
      adsense_enabled: false
    };
  },

  async updatePlatformSettings(data: Partial<PlatformSettingsDoc>): Promise<PlatformSettingsDoc> {
    const ref = doc(firestoreDb, 'settings', 'platform_config');
    const current = await this.getPlatformSettings();
    const updated: PlatformSettingsDoc = {
      ...current,
      ...data,
      monetization_enabled: false,
      subscriptions_enabled: false,
      featured_stores_enabled: false,
      store_ads_enabled: false,
      admob_enabled: false,
      adsense_enabled: false,
      updated_at: new Date().toISOString()
    };
    await setDoc(ref, updated, { merge: true });
    return updated;
  }
};

export interface PlatformSettingsDoc {
  platform_name: string;
  support_phone: string;
  support_email: string;
  city: string;
  require_store_approval: boolean;
  store_visibility_rule: 'approved_active_valid_location' | 'approved_active_open_only';
  service_available: boolean;
  maintenance_message: string;
  monetization_enabled: boolean;
  subscriptions_enabled: boolean;
  featured_stores_enabled: boolean;
  store_ads_enabled: boolean;
  admob_enabled: boolean;
  adsense_enabled: boolean;
  updated_at: string;
}

// ----------------------------------------------------
// DELIVERY SLOTS REPOSITORY
// ----------------------------------------------------
export interface DeliverySlotDoc {
  id: number;
  name: string;
  time_window: string;
  max_orders_per_slot: number;
  is_active: boolean;
  display_order: number;
}

export const deliverySlotsRepo = {
  async list(): Promise<DeliverySlotDoc[]> {
    const snap = await getDocs(collection(firestoreDb, 'delivery_slots'));
    const list = snap.docs.map(d => d.data() as DeliverySlotDoc).filter(s => s.is_active !== false);
    return list.sort((a, b) => (a.display_order || 0) - (b.display_order || 0) || a.id - b.id);
  },

  async create(data: Omit<DeliverySlotDoc, 'id'>, customId?: number): Promise<DeliverySlotDoc> {
    const id = customId || (await getNextId('delivery_slots'));
    const slot: DeliverySlotDoc = { ...data, id };
    await setDoc(doc(firestoreDb, 'delivery_slots', String(id)), slot);
    return slot;
  },

  async update(id: number, data: Partial<DeliverySlotDoc>): Promise<DeliverySlotDoc | null> {
    const ref = doc(firestoreDb, 'delivery_slots', String(id));
    const snap = await getDoc(ref);
    if (!snap.exists()) return null;
    const updated = { ...snap.data(), ...data };
    await setDoc(ref, updated, { merge: true });
    return updated as DeliverySlotDoc;
  },

  async deactivate(id: number): Promise<boolean> {
    const ref = doc(firestoreDb, 'delivery_slots', String(id));
    const snap = await getDoc(ref);
    if (!snap.exists()) return false;
    await updateDoc(ref, { is_active: false });
    return true;
  }
};

// ----------------------------------------------------
// NOTIFICATIONS REPOSITORY
// ----------------------------------------------------
export interface NotificationDoc {
  id: number;
  user_id: number;
  title: string;
  message: string;
  type: string;
  is_read: boolean;
  order_id?: number | null;
  created_at: string;
}

export const notificationsRepo = {
  async listForUser(userId: number): Promise<NotificationDoc[]> {
    const snap = await getDocs(collection(firestoreDb, 'notifications'));
    const notifs = snap.docs
      .map(d => d.data() as NotificationDoc)
      .filter(n => n.user_id === userId);
    return notifs
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
      .slice(0, 25);
  },

  async create(data: Omit<NotificationDoc, 'id' | 'is_read' | 'created_at'>): Promise<NotificationDoc> {
    const id = Date.now() + Math.floor(Math.random() * 1000);
    const notif: NotificationDoc = {
      ...data,
      id,
      is_read: false,
      created_at: new Date().toISOString()
    };
    await setDoc(doc(firestoreDb, 'notifications', String(id)), notif);
    return notif;
  },

  async markRead(id: number, userId: number): Promise<boolean> {
    const ref = doc(firestoreDb, 'notifications', String(id));
    const snap = await getDoc(ref);
    if (!snap.exists() || snap.data()?.user_id !== userId) return false;
    await updateDoc(ref, { is_read: true });
    return true;
  },

  async markAllRead(userId: number): Promise<boolean> {
    const snap = await getDocs(collection(firestoreDb, 'notifications'));
    const userNotifs = snap.docs.filter(d => d.data()?.user_id === userId && !d.data()?.is_read);
    for (const d of userNotifs) {
      await updateDoc(d.ref, { is_read: true });
    }
    return true;
  }
};

// ----------------------------------------------------
// FAVORITES REPOSITORY
// ----------------------------------------------------
export interface FavoriteDoc {
  id: number;
  customer_id: number;
  product_id: number;
  created_at: string;
}

export const favoritesRepo = {
  async listForCustomer(customerId: number): Promise<any[]> {
    const snap = await getDocs(collection(firestoreDb, 'favorites'));
    const favs = snap.docs
      .map(d => d.data() as FavoriteDoc)
      .filter(f => f.customer_id === customerId);

    const products = await productsRepo.list();
    const prodMap = new Map(products.map(p => [p.id, p]));

    return favs
      .map(f => {
        const prod = prodMap.get(f.product_id);
        if (!prod) return null;
        return {
          ...prod,
          favorited_at: f.created_at
        };
      })
      .filter(Boolean);
  },

  async toggle(customerId: number, productId: number): Promise<boolean> {
    const snap = await getDocs(collection(firestoreDb, 'favorites'));
    const existing = snap.docs.find(
      d => d.data()?.customer_id === customerId && d.data()?.product_id === productId
    );

    if (existing) {
      await deleteDoc(existing.ref);
      return false; // Removed
    } else {
      const id = Date.now() + Math.floor(Math.random() * 500);
      await setDoc(doc(firestoreDb, 'favorites', String(id)), {
        id,
        customer_id: customerId,
        product_id: productId,
        created_at: new Date().toISOString()
      });
      return true; // Added
    }
  }
};

// ----------------------------------------------------
// REVIEWS REPOSITORY
// ----------------------------------------------------
export interface ReviewDoc {
  id: number;
  product_id: number;
  customer_id: number;
  customer_name: string;
  order_id?: number | null;
  rating: number;
  review_text: string;
  status: 'approved' | 'rejected';
  created_at: string;
}

export const reviewsRepo = {
  async listForProduct(productId: number): Promise<{ reviews: ReviewDoc[]; stats: { review_count: number; average_rating: number } }> {
    const snap = await getDocs(collection(firestoreDb, 'reviews'));
    const reviews = snap.docs
      .map(d => d.data() as ReviewDoc)
      .filter(r => r.product_id === productId && r.status === 'approved')
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

    const count = reviews.length;
    const avg = count > 0 ? Number((reviews.reduce((s, r) => s + r.rating, 0) / count).toFixed(1)) : 0;
    return { reviews, stats: { review_count: count, average_rating: avg } };
  },

  async create(data: Omit<ReviewDoc, 'id' | 'created_at'>): Promise<ReviewDoc> {
    const id = Date.now() + Math.floor(Math.random() * 500);
    const review: ReviewDoc = {
      ...data,
      id,
      created_at: new Date().toISOString()
    };
    await setDoc(doc(firestoreDb, 'reviews', String(id)), review);
    return review;
  },

  async listAll(): Promise<any[]> {
    const snap = await getDocs(collection(firestoreDb, 'reviews'));
    const reviews = snap.docs
      .map(d => d.data() as ReviewDoc)
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

    const products = await productsRepo.list();
    const prodMap = new Map(products.map(p => [p.id, p]));

    return reviews.map(r => ({
      ...r,
      product_name: prodMap.get(r.product_id)?.name || `Product #${r.product_id}`,
      product_image: prodMap.get(r.product_id)?.image_url || null
    }));
  },

  async updateStatus(id: number, status: 'approved' | 'rejected'): Promise<ReviewDoc | null> {
    const ref = doc(firestoreDb, 'reviews', String(id));
    const snap = await getDoc(ref);
    if (!snap.exists()) return null;
    const updated = { ...snap.data(), status };
    await setDoc(ref, updated, { merge: true });
    return updated as ReviewDoc;
  },

  async deleteReview(id: number): Promise<boolean> {
    const ref = doc(firestoreDb, 'reviews', String(id));
    const snap = await getDoc(ref);
    if (!snap.exists()) return false;
    await deleteDoc(ref);
    return true;
  }
};

// ----------------------------------------------------
// SUPPLIERS & PURCHASE ORDERS REPOSITORY
// ----------------------------------------------------
export interface SupplierDoc {
  id: number;
  name: string;
  contact_person: string;
  phone: string;
  email: string | null;
  address: string;
  city: string;
  gst_number: string;
  created_at: string;
}

export interface PurchaseOrderDoc {
  id: number;
  po_number: string;
  supplier_id: number;
  supplier_name: string;
  status: 'pending' | 'received';
  total_amount: number;
  notes: string | null;
  created_at: string;
  received_at?: string | null;
  item_count?: number;
}

export interface PurchaseOrderItemDoc {
  id: number;
  purchase_order_id: number;
  product_id: number;
  product_name: string;
  quantity: number;
  cost_price: number;
  total: number;
}

export const suppliersRepo = {
  async list(): Promise<SupplierDoc[]> {
    const snap = await getDocs(collection(firestoreDb, 'suppliers'));
    return snap.docs.map(d => d.data() as SupplierDoc).sort((a, b) => a.id - b.id);
  },

  async findById(id: number): Promise<SupplierDoc | null> {
    const ref = doc(firestoreDb, 'suppliers', String(id));
    const snap = await getDoc(ref);
    return snap.exists() ? (snap.data() as SupplierDoc) : null;
  },

  async create(data: Omit<SupplierDoc, 'id' | 'created_at'>, customId?: number): Promise<SupplierDoc> {
    const id = customId || (await getNextId('suppliers'));
    const sup: SupplierDoc = { ...data, id, created_at: new Date().toISOString() };
    await setDoc(doc(firestoreDb, 'suppliers', String(id)), sup);
    return sup;
  }
};

export const purchaseOrdersRepo = {
  async list(): Promise<PurchaseOrderDoc[]> {
    const snap = await getDocs(collection(firestoreDb, 'purchase_orders'));
    const itemsSnap = await getDocs(collection(firestoreDb, 'purchase_order_items'));
    const items = itemsSnap.docs.map(d => d.data() as PurchaseOrderItemDoc);

    const countMap: Record<number, number> = {};
    for (const it of items) {
      countMap[it.purchase_order_id] = (countMap[it.purchase_order_id] || 0) + 1;
    }

    const pos = snap.docs.map(d => {
      const data = d.data() as PurchaseOrderDoc;
      return {
        ...data,
        item_count: countMap[data.id] || 0
      };
    });
    return pos.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
  },

  async create(supplierId: number, items: { product_id: number; product_name: string; quantity: number; cost_price: number }[], notes?: string): Promise<PurchaseOrderDoc> {
    const supplier = await suppliersRepo.findById(supplierId);
    if (!supplier) throw new Error('Supplier not found.');

    const poNumber = `PO-KL-${Date.now().toString().slice(-6)}`;
    const poId = Date.now() + Math.floor(Math.random() * 500);
    const nowIso = new Date().toISOString();

    let totalAmount = 0;
    for (const it of items) totalAmount += Number(it.cost_price) * Number(it.quantity);

    const po: PurchaseOrderDoc = {
      id: poId,
      po_number: poNumber,
      supplier_id: supplierId,
      supplier_name: supplier.name,
      status: 'pending',
      total_amount: totalAmount,
      notes: notes || null,
      created_at: nowIso
    };
    await setDoc(doc(firestoreDb, 'purchase_orders', String(poId)), po);

    let counter = 0;
    for (const it of items) {
      counter++;
      const itemId = Date.now() + counter + Math.floor(Math.random() * 100);
      const itemDoc: PurchaseOrderItemDoc = {
        id: itemId,
        purchase_order_id: poId,
        product_id: it.product_id,
        product_name: it.product_name,
        quantity: it.quantity,
        cost_price: it.cost_price,
        total: Number(it.cost_price) * Number(it.quantity)
      };
      await setDoc(doc(firestoreDb, 'purchase_order_items', String(itemId)), itemDoc);
    }

    return po;
  },

  async receive(id: number): Promise<PurchaseOrderDoc> {
    const poRef = doc(firestoreDb, 'purchase_orders', String(id));
    const poSnap = await getDoc(poRef);
    if (!poSnap.exists()) throw new Error('Purchase order not found.');
    const po = poSnap.data() as PurchaseOrderDoc;
    if (po.status === 'received') throw new Error('Purchase order has already been received.');

    const itemsSnap = await getDocs(collection(firestoreDb, 'purchase_order_items'));
    const items = itemsSnap.docs
      .map(d => d.data() as PurchaseOrderItemDoc)
      .filter(i => i.purchase_order_id === id);

    for (const it of items) {
      const prod = await productsRepo.findById(it.product_id);
      if (prod) {
        const newStock = prod.stock + it.quantity;
        await productsRepo.update(prod.id, { stock: newStock });
        const logId = Date.now() + Math.floor(Math.random() * 1000);
        await setDoc(doc(firestoreDb, 'inventory', String(logId)), {
          id: logId,
          product_id: it.product_id,
          change_type: 'purchase_receive',
          quantity_change: it.quantity,
          stock_after: newStock,
          reference_id: po.po_number,
          notes: `Received via PO ${po.po_number}`,
          created_at: new Date().toISOString()
        });
      }
    }

    const updated: PurchaseOrderDoc = {
      ...po,
      status: 'received',
      received_at: new Date().toISOString()
    };
    await setDoc(poRef, updated, { merge: true });
    return updated;
  }
};

// ----------------------------------------------------
// COD RECONCILIATIONS REPOSITORY
// ----------------------------------------------------
export interface CodReconciliationDoc {
  id: number;
  reconciliation_number: string;
  rider_id: number;
  rider_name: string;
  total_amount: number;
  order_count: number;
  order_ids: string;
  reconciled_by: number;
  notes: string | null;
  created_at: string;
}

export const codReconciliationsRepo = {
  async getPendingPerRider(): Promise<any[]> {
    const riders = await usersRepo.listRiders();
    const orders = await ordersRepo.list();

    const pendingOrders = orders.filter(
      o => o.cod_collected === true && (o.cod_reconciled === false || !o.cod_reconciled)
    );

    const riderSummaryMap: Record<number, { count: number; total: number }> = {};
    for (const o of pendingOrders) {
      if (o.rider_id) {
        if (!riderSummaryMap[o.rider_id]) riderSummaryMap[o.rider_id] = { count: 0, total: 0 };
        riderSummaryMap[o.rider_id].count++;
        riderSummaryMap[o.rider_id].total += Number(o.total_amount) || 0;
      }
    }

    return riders
      .map(r => ({
        rider_id: r.id,
        rider_name: r.name,
        rider_phone: r.phone,
        unreconciled_order_count: riderSummaryMap[r.id]?.count || 0,
        total_cash_pending: riderSummaryMap[r.id]?.total || 0
      }))
      .filter(r => r.total_cash_pending > 0)
      .sort((a, b) => b.total_cash_pending - a.total_cash_pending);
  },

  async reconcileRider(riderId: number, adminId: number, notes?: string): Promise<CodReconciliationDoc> {
    const rider = await usersRepo.findById(riderId);
    if (!rider) throw new Error('Delivery rider not found.');

    const orders = await ordersRepo.list();
    const pendingOrders = orders.filter(
      o => o.rider_id === riderId && o.cod_collected === true && (o.cod_reconciled === false || !o.cod_reconciled)
    );

    if (pendingOrders.length === 0) {
      throw new Error('No pending COD cash to reconcile for this delivery rider.');
    }

    const recNumber = `REC-KL-${Date.now().toString().slice(-6)}`;
    const recId = Date.now() + Math.floor(Math.random() * 500);
    const totalAmount = pendingOrders.reduce((sum, o) => sum + Number(o.total_amount), 0);
    const orderIds = pendingOrders.map(o => o.id);
    const nowIso = new Date().toISOString();

    for (const o of pendingOrders) {
      await updateDoc(doc(firestoreDb, 'orders', String(o.id)), {
        cod_reconciled: true,
        cod_reconciled_at: nowIso,
        updated_at: nowIso
      });
    }

    const rec: CodReconciliationDoc = {
      id: recId,
      reconciliation_number: recNumber,
      rider_id: riderId,
      rider_name: rider.name,
      total_amount: totalAmount,
      order_count: orderIds.length,
      order_ids: JSON.stringify(orderIds),
      reconciled_by: adminId,
      notes: notes || null,
      created_at: nowIso
    };
    await setDoc(doc(firestoreDb, 'cod_reconciliations', String(recId)), rec);

    await notificationsRepo.create({
      user_id: riderId,
      title: 'COD Cash Handed Over & Reconciled ✅',
      message: `Admin reconciled ₹${totalAmount} collected across ${orderIds.length} orders (Ref: #${recNumber}).`,
      type: 'reconciliation'
    });

    return rec;
  }
};

// ----------------------------------------------------
// AUDIT LOGS & PASSWORD RESET
// ----------------------------------------------------
export const auditLogsRepo = {
  async create(data: {
    user_id: number | null;
    user_role: string | null;
    action: string;
    entity: string;
    entity_id: string | number | null;
    details: string;
    ip_address?: string;
  }): Promise<void> {
    const id = Date.now() + Math.floor(Math.random() * 1000);
    await setDoc(doc(firestoreDb, 'audit_logs', String(id)), {
      id,
      ...data,
      entity_id: data.entity_id ? String(data.entity_id) : null,
      ip_address: data.ip_address || 'internal',
      created_at: new Date().toISOString()
    });
  },

  async list(limitCount: number = 50): Promise<any[]> {
    const snap = await getDocs(collection(firestoreDb, 'audit_logs'));
    const list = snap.docs.map(d => d.data());
    return list
      .sort((a: any, b: any) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
      .slice(0, limitCount);
  }
};

export const passwordResetsRepo = {
  async create(phone: string, name: string, role: string, notes?: string): Promise<any> {
    const id = Date.now() + Math.floor(Math.random() * 500);
    const req = {
      id,
      phone,
      name,
      role,
      status: 'pending',
      notes: notes || 'Requested via single login portal',
      created_at: new Date().toISOString()
    };
    await setDoc(doc(firestoreDb, 'password_reset_requests', String(id)), req);
    return req;
  },

  async listPending(): Promise<any[]> {
    const snap = await getDocs(collection(firestoreDb, 'password_reset_requests'));
    return snap.docs
      .map(d => d.data())
      .sort((a: any, b: any) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
      .slice(0, 50);
  },

  async resolve(phone: string, requestId?: number): Promise<void> {
    const snap = await getDocs(collection(firestoreDb, 'password_reset_requests'));
    const matches = snap.docs.filter(d => {
      const data = d.data();
      if (requestId) return data.id === requestId;
      return data.phone === phone && data.status === 'pending';
    });
    for (const d of matches) {
      await updateDoc(d.ref, {
        status: 'resolved',
        resolved_at: new Date().toISOString()
      });
    }
  }
};

export interface SavedAddressDoc {
  id: number;
  user_id: number;
  label: string;
  recipient_name?: string;
  phone?: string;
  address: string;
  landmark?: string;
  pincode?: string;
  lat?: number | null;
  lng?: number | null;
  is_default: boolean;
  created_at: string;
}

export const addressesRepo = {
  async listByUser(userId: number): Promise<SavedAddressDoc[]> {
    const q = query(collection(firestoreDb, 'addresses'), where('user_id', '==', userId));
    const snap = await getDocs(q);
    return snap.docs
      .map(d => d.data() as SavedAddressDoc)
      .sort((a, b) => Number(Boolean(b.is_default)) - Number(Boolean(a.is_default)) || new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
  },

  async create(userId: number, data: Omit<SavedAddressDoc, 'id' | 'user_id' | 'created_at'>): Promise<SavedAddressDoc> {
    const id = await getNextId('addresses');
    const addrDoc: SavedAddressDoc = {
      ...data,
      id,
      user_id: userId,
      created_at: new Date().toISOString()
    };
    await setDoc(doc(firestoreDb, 'addresses', String(id)), addrDoc);
    return addrDoc;
  },

  async remove(userId: number, id: number): Promise<'deleted' | 'not_found' | 'forbidden'> {
    const ref = doc(firestoreDb, 'addresses', String(id));
    const snap = await getDoc(ref);
    if (!snap.exists()) return 'not_found';
    const existing = snap.data() as SavedAddressDoc;
    if (existing.user_id !== userId) return 'forbidden';
    await deleteDoc(ref);
    return 'deleted';
  }
};

// ----------------------------------------------------
// INITIAL FIRESTORE DATABASE SEEDER (Pure Firestore, Zero Mocks)
// ----------------------------------------------------
export async function seedFirestoreIfEmpty(): Promise<void> {
  const allowDemoSeed =
    process.env.IS_TEST_SUITE === 'true' ||
    process.env.ALLOW_INSECURE_SEED_DEFAULTS === 'true';

  console.log('🌱 Checking Firestore collections for FMP Supermart hyperlocal marketplace...');

  // 1. Always ensure default product categories & platform config exist
  const existingCats = await categoriesRepo.list(true);
  if (existingCats.length === 0) {
    const categoriesData = [
      { id: 1, name: 'Grocery', slug: 'grocery', desc: 'Flours, Grains, Pulses, Cooking Oils & Masalas', order: 1, img: 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=400&q=80' },
      { id: 2, name: 'Fruits', slug: 'fruits', desc: 'Farm fresh regional & seasonal fruits', order: 2, img: 'https://images.unsplash.com/photo-1619566636858-adf3ef46400b?auto=format&fit=crop&w=400&q=80' },
      { id: 3, name: 'Vegetables', slug: 'vegetables', desc: 'Daily harvest fresh vegetables', order: 3, img: 'https://images.unsplash.com/photo-1597362925123-77861d3fbac7?auto=format&fit=crop&w=400&q=80' },
      { id: 4, name: 'Dairy', slug: 'dairy', desc: 'Fresh Milk, Curd, Paneer, Butter & Ghee', order: 4, img: 'https://images.unsplash.com/photo-1628088062854-d1870b4553da?auto=format&fit=crop&w=400&q=80' },
      { id: 5, name: 'Snacks', slug: 'snacks', desc: 'Namkeen, Biscuits & Daily Snacks', order: 5, img: 'https://images.unsplash.com/photo-1621996346565-e3d5d628169e?auto=format&fit=crop&w=400&q=80' },
      { id: 6, name: 'Beverages', slug: 'beverages', desc: 'Tea, Coffee, Juices & Refreshing Drinks', order: 6, img: 'https://images.unsplash.com/photo-1544787219-7f47ccb76574?auto=format&fit=crop&w=400&q=80' },
      { id: 7, name: 'Household', slug: 'household', desc: 'Detergents, Cleaners & Daily Home Essentials', order: 7, img: 'https://images.unsplash.com/photo-1583947215259-38e31be8751f?auto=format&fit=crop&w=400&q=80' }
    ];

    for (const c of categoriesData) {
      await categoriesRepo.create(
        {
          name: c.name,
          slug: c.slug,
          description: c.desc,
          image_url: c.img,
          display_order: c.order,
          is_active: true
        },
        c.id
      );
    }
  }

  await settingsRepo.getPlatformSettings();

  // 2. Demo / automated test accounts are ONLY seeded when explicitly opted-in (never in normal production)
  if (allowDemoSeed) {
    const adminCheck = await usersRepo.findByPhoneAndRole('9876543210', 'admin');
    if (!adminCheck) {
      const adminHash = await bcrypt.hash('AdminPassword@123', 10);
      await usersRepo.create({
        phone: '9876543210',
        name: 'FMP Supermart Admin',
        email: 'admin@fmpsupermart.in',
        role: 'admin',
        password_hash: adminHash,
        address: 'FMP Supermart Platform Office',
        landmark: 'Karanja Lad',
        city: 'Karanja Lad',
        pincode: '444105',
        is_active: true,
        created_at: new Date().toISOString()
      });
    }

    const customerCheck = await usersRepo.findByPhoneAndRole('9123456780', 'customer');
    if (!customerCheck) {
      const customerHash = await bcrypt.hash('CustomerPassword@123', 10);
      await usersRepo.create({
        phone: '9123456780',
        name: 'Rahul Deshmukh',
        email: 'rahul.karanja@gmail.com',
        role: 'customer',
        password_hash: customerHash,
        address: 'Plot 14, Anand Nagar, Guru Mandir Marg',
        landmark: 'Near Guru Mandir',
        city: 'Karanja Lad',
        pincode: '444105',
        is_active: true,
        created_at: new Date().toISOString()
      });
    }

    const primaryAdmin = await usersRepo.findByPhoneAndRole('9699925206', 'admin');
    if (!primaryAdmin) {
      const primaryAdminHash = await bcrypt.hash('test@12345', 10);
      await usersRepo.create({
        phone: '9699925206',
        name: 'FMP Supermart Admin',
        email: 'admin@fmpsupermart.in',
        role: 'admin',
        password_hash: primaryAdminHash,
        address: 'Karanja Lad',
        landmark: 'Maharashtra',
        city: 'Karanja Lad',
        pincode: '444105',
        is_active: true,
        created_at: new Date().toISOString()
      });
    }
  }

  // Ensure sequence counters have safe floors
  await ensureCounterMin('users', 10);
  await ensureCounterMin('categories', 10);
  await ensureCounterMin('products', 35);
  await ensureCounterMin('stores', 5);

  console.log('✅ Pure Firestore hyperlocal marketplace collections verified and ready!');
}
